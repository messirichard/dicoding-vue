Untuk git bisa langsung aja pull dari github saya, repo sudah saya public
https://github.com/messirichard/dicoding-vue.git

Untuk Tampilan yang sudah terdeploy ada di
https://dicoding-vue.messirichard.now.sh/

untuk bagian webpack ada di folder config dan build

saya menerapkan atomic design untuk tahap development
untuk bagian development bisa jalankan "npm run dev"
untuk bagian production jalankan "npm run build" setelah itu "serve dist" untuk melihat hasilnya

saya memakai vuex untuk getData yang ada di folder src/store/modules
untuk tampilan ada di src/components/page

untuk bagian custom element ada di bagian 
src\components\Page\Global\index.vue
src\components\Page\Global\Confirmed.vue
src\components\Page\Global\Deaths.vue
src\components\Page\Global\Recovered.vue
semua memakai props seperti yang ada di modul dari dicoding hanya saja saya penerapannya di vue

mohon dilihat secara detail setiap code 
tampilan sudah responsive

Terima Kasih 