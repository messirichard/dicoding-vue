<template>
    <v-toolbar-title style="width: 300px" class="ml-0 pl-4">
        <span class="hidden-sm-and-down">Dicoding Submission Corona</span>
      </v-toolbar-title>
</template>

<script>
export default {
}
</script>
