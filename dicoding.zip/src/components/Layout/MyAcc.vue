<template>
    <v-btn icon large>
        <v-avatar size="32px" item>
          <img src="../../assets/logo.png" alt="Logo" />
        </v-avatar>
      </v-btn>
</template>

<script>
export default {

}
</script>
